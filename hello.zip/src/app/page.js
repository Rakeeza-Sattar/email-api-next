export default function Home() {
  return <h1>API is running!</h1>;
}
